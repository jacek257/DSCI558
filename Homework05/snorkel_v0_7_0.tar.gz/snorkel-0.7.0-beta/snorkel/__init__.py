from __future__ import absolute_import

from snorkel.models import SnorkelSession

__version__ = '0.7.0-beta'
